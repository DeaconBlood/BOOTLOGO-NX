apri il prompt dei comandi dentro questa cartella "cmd" ed esegui il comando qui sotto seguente

python gen_patches.py logo logo.png



troverai i file generati dentro la cartella "logo"
